package fu.se180211.employee.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import java.util.Date;

@Getter
@Setter
public class EmployeeDTO {
    private Long employeeId;
    @Size(max = 100)
    private String fullName;
    @Size(max = 100)
    @Email
    private String email;
    @Size(max = 30)
    private String position;
    @Size(max = 10)
    private String status;
    @JsonFormat(pattern = "dd/MM/yyyy", timezone = "UTC")
    private Date startDate;
    @JsonFormat(pattern = "dd/MM/yyyy", timezone = "UTC")
    private Date endDate;
    private DepartmentDTO department;
}
