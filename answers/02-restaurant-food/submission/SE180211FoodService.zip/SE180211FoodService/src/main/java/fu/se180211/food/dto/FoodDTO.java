package fu.se180211.food.dto;

import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FoodDTO {
    private Long foodId;
    @Size(max = 100)
    private String name;
    private Integer price;
    @Size(max = 500)
    private String ingredients;
    @Size(max = 20)
    private String status;
    private Long restaurantId;
}
