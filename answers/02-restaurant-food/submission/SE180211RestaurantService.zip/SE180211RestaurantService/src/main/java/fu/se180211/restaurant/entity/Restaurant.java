package fu.se180211.restaurant.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = "restaurants")
public class Restaurant {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "restaurant_id")
    private Long restaurantId;

    @Column(name = "name", nullable = false, unique = true, length = 100)
    private String name;

    @Column(name = "owner_name", nullable = false, length = 100)
    private String owner;

    @Column(name = "address", nullable = false, length = 100)
    private String address;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "open_date", nullable = false)
    private Date openDate;

    @Column(name = "price_from")
    private Integer priceFrom;

    @Column(name = "price_to")
    private Integer priceTo;

    @Column(name = "phone", nullable = false, length = 11)
    private String phone;

    @Column(name = "status", nullable = false, length = 10)
    private String status;

    @Column(name = "category_id", nullable = false)
    private Long categoryId;

}
